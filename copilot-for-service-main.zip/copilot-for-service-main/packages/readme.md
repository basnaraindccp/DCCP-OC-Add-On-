To enable Copilot before GA rollout, the solutions in this packages folder needs to be imported to the associated Microsoft Dynamics environment.

Below is the order in which the solutions should be installed:

1. msdyn_CSIntelligenceConfiguration_managed.cab
2. msdyn_CSIntelligenceCore_managed.cab
3. msdyn_CSIntelligence_managed.cab

During import, under
Solution Action, choose Update (defaults to Upgrade)
Previous customizations on components included in this solution, choose Overwrite customizations (defaults to Maintain customizations)
